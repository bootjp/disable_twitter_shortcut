# disable_twitter_shortcut
Twitterのキーボードショートカットを無効化する / disable twitter web keyboard shortcut.
